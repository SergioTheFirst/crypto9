Скопируй сюда файлы Redis для Windows (redis-server.exe и др.)
